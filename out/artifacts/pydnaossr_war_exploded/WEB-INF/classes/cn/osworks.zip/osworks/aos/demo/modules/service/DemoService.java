package cn.osworks.aos.demo.modules.service;

import org.springframework.stereotype.Service;

/**
 * 范例模块UI组件服务
 * 
 * @author AHei
 */
@Service
public class DemoService {

}
